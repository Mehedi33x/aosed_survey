CKEDITOR.editorConfig = function (config) {
    // Define changes to default configuration here. For example:
    // config.language = 'fr';
    // config.uiColor = '#AADC6E';
    //  config.extraPlugins = 'cloudservices';
    var base_url = $('head').data('baseurl');
    config.removePlugins = 'easyimage, cloudservices,image';

    config.filebrowserBrowseUrl = base_url + '/ckfinder/ckfinder.html';

    // config.filebrowserImageBrowseUrl = base_url + '/ckfinder.html?type=Images';

    // config.filebrowserFlashBrowseUrl = base_url + '/ckfinder.html?type=Flash';

    config.filebrowserUploadUrl = base_url + '/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';

    config.filebrowserImageUploadUrl = base_url + '/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';

    config.filebrowserFlashUploadUrl = base_url + '/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';
    config.mathJaxLib = '//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML';

};

